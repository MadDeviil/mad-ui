function Show(text , type, press)
    if press ~= nil and press ~= "" and press ~= " " then
        PlaySound(-1, "CLICK_BACK", "WEB_NAVIGATION_SOUNDS_PHONE", 0, 0, 1)
        SendNUIMessage({
            type = "open",
            text = text,
            color = type,
            press = press,
        })
    else
        PlaySound(-1, "CLICK_BACK", "WEB_NAVIGATION_SOUNDS_PHONE", 0, 0, 1)
        SendNUIMessage({
            type = "open2",
            text = text,
            press = press,
            color = type,
        })
    end
end

function Hide()
    SendNUIMessage({
        type = "close",
    })
end



RegisterCommand('ClearUi', function(source, args, RawCommand)
    Hide()
end)