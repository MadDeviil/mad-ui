fx_version 'cerulean'
games { 'rdr3', 'gta5' }


client_scripts {
    'client.lua'
}

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/css/master.css',
    'html/js/app.js'
}

exports {
	'Show',
    'Hide'
}