window.addEventListener('message', function (event) {
    if (event.data.type == "open") {
      var color = '#ff9411'
      var cc = 'color: #ff9411'
      if (event.data.color == 'error') {
        color = '#ff9411'
        cc = 'color: red'
      } else if (event.data.color == 'info' || event.data.color == null) {
        color = '#ff9411'
        cc = 'color: #2d78ce'
      } else if (event.data.color == 'success') {
        color = '#ff9411'
        cc = 'color: #2dce2d'
      }
      $("#container").show().removeClass("slide-out").addClass("container")
      $("#text").css(color)
      $("#text").html(event.data.text)  
      // <i style="'+cc+' "class="fas fa-info-circle"> </i>' +
      let press1 = event.data.press
      var press = press1.toUpperCase()
      $(".back-area").html(press + ":")
      var TextWidth = $('#text').outerWidth() - 13;
      // $('#text::after').attr('data-before', TextWidth + 'px')              
    } else if (event.data.type == "close") {
      $("#container").removeClass("container").addClass("slide-out")
      $("#container2").removeClass("container2").addClass("slide-out")

    } else if (event.data.type == "open2") {
        $("#container").hide()
      $("#container2").show().removeClass("slide-out").addClass("container2")
      $("#text2").css('background-color', color)
      $("#text2").html(`<i class="fa-solid fa-circle-info icon-in"></i> ${event.data.text}`)
      //$(".container::after").css("content", event.data.press)

    } else {
      $("#container").hide()

    }
  });